<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-02-13 11:14:51 --> UTF-8 Support Enabled
DEBUG - 2024-02-13 11:14:51 --> No URI present. Default controller set.
DEBUG - 2024-02-13 11:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-13 11:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-13 11:14:51 --> Total execution time: 0.0165
DEBUG - 2024-02-13 11:15:32 --> UTF-8 Support Enabled
DEBUG - 2024-02-13 11:15:32 --> No URI present. Default controller set.
DEBUG - 2024-02-13 11:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-13 11:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-13 11:15:32 --> Total execution time: 0.0183
DEBUG - 2024-02-13 11:15:35 --> UTF-8 Support Enabled
DEBUG - 2024-02-13 11:15:35 --> No URI present. Default controller set.
DEBUG - 2024-02-13 11:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-02-13 11:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-02-13 11:15:35 --> Total execution time: 0.0169
