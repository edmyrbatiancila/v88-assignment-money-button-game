<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Money Button Game</title>
        <link rel="stylesheet" href="<?= base_url('assets/css/styles.css'); ?>">
    </head>
    <body>
        <div class="container">
            <header>
                <p><span>Your money: <?= $this->session->userdata('current_money'); ?></span></p>
                <form class="resetting" action="http://vhedmyr/CI_Money_Button_Game/" method="POST">
                    <input type="hidden" name="action" value="reset">
                    <input class="color" type="submit" value="Reset Game">
                </form>
            </header>
            <section class="bet">
<?php 
    if ($this->session->userdata('current_money') < 0) { 
?>
                <h1>Game Over!!</h1>
                <h3>Please reset the game!!</h3>
<?php 
    } 
    else 
    { 
?>
<?php $this->load->view('partials/form')?>

                    <span>Low Risk</span>
                    <input type="hidden" name="button" value="low">
                    <input class="low" type="submit" value="Bet">
                    <p>by -25 up to 100</p>
                </form>
<?php $this->load->view('partials/form')?>

                    <span>Moderate Risk</span>
                    <input type="hidden" name="button" value="moderate">
                    <input type="submit" value="Bet">
                    <p>by -100 up to 1000</p>
                </form>
<?php $this->load->view('partials/form')?>

                    <span>High Risk</span>
                    <input type="hidden" name="button" value="high">
                    <input class="high" type="submit" value="Bet">
                    <p>by -500 up to 2500</p>
                </form>
<?php $this->load->view('partials/form')?>

                    <span>Severe Risk</span>
                    <input type="hidden" name="button" value="severe">
                    <input type="submit" value="Bet">
                    <p>by -3000 up to 5000</p>
                </form>
    <?php 
        } 
    ?>
            </section>
            <section>
                <p>Game Host:</p>
                <div class="host">
    <?php 
        if ($this->session->userdata('verdict')) { 
            $messages = $this->session->userdata('messages');
            if (!is_array($messages)) {
                $messages = explode(" . ", $messages);
            }
            $result = implode(" ", $messages);
    ?>
                    <?= $result ?>
    <?php
        } 
    ?>
                </div>
            </section>
        </div>
    </body>
</html>
