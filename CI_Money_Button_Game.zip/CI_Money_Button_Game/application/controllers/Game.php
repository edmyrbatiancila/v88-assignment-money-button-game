<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Game extends CI_Controller {

    public function __construct() {
        parent::__construct();
        date_default_timezone_set('Asia/Singapore');
        $this->load->library('session');
        
    }

    public function index() {
        
        // reset the game:
        if ($this->input->post('action') == 'reset') {
            $this->session->sess_destroy();
            redirect('/');
            var_dump($this->input->post());
        }

        // starting money:
        if (!$this->session->userdata('current_money')) {
            $this->session->set_userdata('current_money', 500);
        }
        
        // Logic for bet buttons (Low, Moderate, High and Severe Risks);
        if ($this->input->post('button') && $this->input->post('button') == 'low') {
            $low_bets = rand(-25, 100);
            $this->session->set_userdata('current_money', $this->session->userdata('current_money') + $low_bets);
            if($low_bets < 0) {
                $this->session->set_userdata('verdict', "fail");
            }
            else {
                $this->session->set_userdata('verdict', "gain");
            }
            $this->session->set_userdata('messages', array("<p class=" .$this->session->userdata('verdict'). ">" .date("m/d/y") . " " . strtoupper(date("h:i:a")). " " . "You pushed Low Risk. Value is $low_bets. Your current money is " . $this->session->userdata('current_money').  "</p>"));
        }

        if ($this->input->post('button') && $this->input->post('button') == 'moderate') {
            $moderate_bets = rand(-100, 1000);
            $this->session->set_userdata('current_money', $this->session->userdata('current_money') + $moderate_bets);
            if($moderate_bets < 0) {
                $this->session->set_userdata('verdict', "fail");
            }
            else {
                $this->session->set_userdata('verdict', "gain");
            }
            $this->session->set_userdata('messages', "<p class=" .$this->session->userdata('verdict')."> " . date("m/d/y") . " " . strtoupper(date("h:i:a")) . " " . "You pushed Moderate Risk. Value is $moderate_bets. Your current money is " . $this->session->userdata('current_money') . "</p>");
        }

        if ($this->input->post('button') && $this->input->post('button') == 'high') {
            $high_bets = rand(-500, 2500);
            $this->session->set_userdata('current_money', $this->session->userdata('current_money') + $high_bets);
            if($high_bets < 0) {
                $this->session->set_userdata('verdict', "fail");
            }
            else {
                $this->session->set_userdata('verdict', "gain");
            }
            $this->session->set_userdata('messages', "<p class=" .$this->session->userdata('verdict'). ">" . date("m/d/y") . " " . strtoupper(date("h:i:a")) . " " . "You pushed High Risk. Value is $high_bets. Your current money is " . $this->session->userdata('current_money') . "</p>");
        }

        if ($this->input->post('button') && $this->input->post('button') == 'severe') {
            $severe_bets = rand(-3000, 5000);
            $this->session->set_userdata('current_money', $this->session->userdata('current_money') + $severe_bets);
            if($severe_bets < 0) {
                $this->session->set_userdata('verdict', "fail");
            }
            else {
                $this->session->set_userdata('verdict', "gain");
            }
            $this->session->set_userdata('messages', "<p class=" .$this->session->userdata('verdict'). ">" . date("m/d/y") . " " . strtoupper(date("h:i:a")) . " " . "You pushed Severe Risk. Value is $severe_bets. Your current money is " . $this->session->userdata('current_money') . "</p>");
        }
        $this->load->view('game/index');
    }
}
